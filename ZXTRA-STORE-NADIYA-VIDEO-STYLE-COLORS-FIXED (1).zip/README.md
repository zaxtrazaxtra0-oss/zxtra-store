# ZXTRA STORE — NADIYA-style marketplace

A responsive Free Fire account marketplace inspired by the supplied NADIYA STORE screen recording, rebuilt with ZXTRA STORE branding and owner-controlled account listings.

## Run
1. Install Node.js 18+.
2. `npm install`
3. `npm start`
4. Open `http://localhost:3000`

## Owner admin
Open `/admin.html`.
Initial login: `admin` / `ZXTRA@12345`.
Change the password immediately.

## Features
- Mobile-first red/orange/white NADIYA-inspired visual system
- Separate Home, Browse Accounts and Account Details pages
- Account cards with photos, status, price, old price, level, rank and stats
- Account details page with gallery and WhatsApp CTA
- Owner-only server-side admin login
- Add/edit/delete accounts, upload multiple photos, mark Sold/Available
- Store WhatsApp, bank and Easy Cash settings
- Change admin password

Use HTTPS and environment variables `ADMIN_USER`, `ADMIN_PASSWORD`, `SESSION_SECRET` in production.
