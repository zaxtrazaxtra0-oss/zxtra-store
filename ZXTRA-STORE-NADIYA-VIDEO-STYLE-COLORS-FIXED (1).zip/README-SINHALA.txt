ZXTRA STORE — FINAL PACKAGE

ඔයාගේ website එක: Home Page, Browse Accounts, එක් account එකකට වෙනම details page, SOLD/AVAILABLE badges, On Sale/Grand Prize filters සහ owner Admin Panel.

DESIGN PREVIEW (Android):
1. ZIP එක සම්පූර්ණයෙන් Extract කරන්න. ZIP preview එක ඇතුළේ HTML එක open කරන්න එපා.
2. Extract කළ folder එකේ public/index.html open කරන්න.
3. Accounts page එකට Browse Accounts click කරන්න. Demo accounts පෙන්නයි; ඒවා example පමණයි.

REAL WEBSITE / ADMIN PANEL:
Admin Panel එක සහ account upload/edit/delete සම්පූර්ණයෙන් වැඩ කිරීමට Node.js server එක run/host කරන්න.
Commands: npm install
npm start

Admin default login: admin / ZXTRA@12345
First login එකෙන් පසු password වෙනස් කරන්න.
WhatsApp: 0774099072

IMPORTANT: Demo cards are placeholders. ඔයාගේම account names, prices, levels, ranks සහ photos Admin Panel එකෙන් add කරන්න. Local HTML preview එකේ server-side Admin login වැඩ නොකරයි; ඒ සඳහා server එක අවශ්‍යයි.
