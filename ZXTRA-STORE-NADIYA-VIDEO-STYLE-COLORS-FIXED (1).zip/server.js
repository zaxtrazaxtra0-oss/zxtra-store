const express=require('express');
const session=require('express-session');
const bcrypt=require('bcryptjs');
const multer=require('multer');
const fs=require('fs');
const path=require('path');
const app=express();
const PORT=process.env.PORT||3000;
const DB=path.join(__dirname,'data','db.json');
const UP=path.join(__dirname,'public','uploads');
if(!fs.existsSync(path.dirname(DB)))fs.mkdirSync(path.dirname(DB),{recursive:true});
if(!fs.existsSync(UP))fs.mkdirSync(UP,{recursive:true});
function read(){try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch{return {settings:{storeName:'ZXTRA STORE',whatsapp:'0774099072',bank:'',easyCash:''},accounts:[],users:[]}}}
function write(d){fs.writeFileSync(DB,JSON.stringify(d,null,2))}
let db=read();
if(!db.settings)db.settings={storeName:'ZXTRA STORE',whatsapp:'0774099072',bank:'',easyCash:''};
if(!Array.isArray(db.accounts))db.accounts=[];if(!Array.isArray(db.users))db.users=[];
if(!db.users.length){db.users.push({id:1,username:process.env.ADMIN_USER||'admin',password:bcrypt.hashSync(process.env.ADMIN_PASSWORD||'ZXTRA@12345',12),role:'admin'});write(db)}
app.use(express.json({limit:'3mb'}));app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET||'change-this-session-secret',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/uploads',express.static(UP));
const storage=multer.diskStorage({destination:(r,f,cb)=>cb(null,UP),filename:(r,f,cb)=>cb(null,Date.now()+'-'+Math.random().toString(36).slice(2,9)+path.extname(f.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:7*1024*1024},fileFilter:(r,f,cb)=>/^image\/(jpeg|png|webp|gif)$/.test(f.mimetype)?cb(null,true):cb(new Error('Only image files are allowed'))});
const admin=(r,s,n)=>r.session?.user?.role==='admin'?n():s.status(401).json({error:'Unauthorized'});
app.get('/api/store',(r,s)=>{db=read();s.json({settings:db.settings,accounts:db.accounts})});
app.post('/api/login',(r,s)=>{db=read();const {username,password}=r.body||{};const u=db.users.find(x=>x.username===username);if(!u||!bcrypt.compareSync(password||'',u.password))return s.status(401).json({error:'Invalid login details'});r.session.user={id:u.id,username:u.username,role:u.role};s.json({ok:true,user:r.session.user})});
app.post('/api/logout',(r,s)=>r.session.destroy(()=>s.json({ok:true})));app.get('/api/me',(r,s)=>s.json({user:r.session.user||null}));
app.get('/api/admin/accounts',admin,(r,s)=>{db=read();s.json(db.accounts)});
function makeAccount(b,images,old){return {...old,id:old?.id||Date.now().toString(36),title:b.title||old?.title||'Untitled Account',price:Number(b.price||old?.price||0),oldPrice:Number(b.oldPrice||old?.oldPrice||0),level:b.level||old?.level||'-',rank:b.rank||old?.rank||'-',uid:b.uid||old?.uid||'',gunSkins:Number(b.gunSkins||old?.gunSkins||0),bundles:Number(b.bundles||old?.bundles||0),diamonds:Number(b.diamonds||old?.diamonds||0),evoGuns:Number(b.evoGuns||old?.evoGuns||0),subscription:b.subscription||old?.subscription||'',details:b.details||old?.details||'',status:b.status==='sold'?'sold':'available',badge:b.badge||old?.badge||'AVAILABLE',images:images.length?(old? [...(old.images||[]),...images]:images):(old?.images||[]),createdAt:old?.createdAt||new Date().toISOString()}}
app.post('/api/admin/accounts',admin,upload.array('images',10),(r,s)=>{db=read();const a=makeAccount(r.body,(r.files||[]).map(f=>'/uploads/'+f.filename));db.accounts.unshift(a);write(db);s.json(a)});
app.put('/api/admin/accounts/:id',admin,upload.array('images',10),(r,s)=>{db=read();const i=db.accounts.findIndex(a=>a.id===r.params.id);if(i<0)return s.status(404).json({error:'Account not found'});db.accounts[i]=makeAccount(r.body,(r.files||[]).map(f=>'/uploads/'+f.filename),db.accounts[i]);write(db);s.json(db.accounts[i])});
app.delete('/api/admin/accounts/:id',admin,(r,s)=>{db=read();const i=db.accounts.findIndex(a=>a.id===r.params.id);if(i<0)return s.status(404).json({error:'Account not found'});db.accounts.splice(i,1);write(db);s.json({ok:true})});
app.post('/api/admin/settings',admin,(r,s)=>{db=read();db.settings={...db.settings,...r.body,whatsapp:String(r.body.whatsapp||db.settings.whatsapp||'0774099072')};write(db);s.json(db.settings)});
app.post('/api/admin/password',admin,(r,s)=>{db=read();const u=db.users.find(x=>x.id===r.session.user.id);if(!u||!bcrypt.compareSync(r.body.currentPassword||'',u.password))return s.status(400).json({error:'Current password is incorrect'});if(!r.body.newPassword||r.body.newPassword.length<10)return s.status(400).json({error:'New password must be at least 10 characters'});u.password=bcrypt.hashSync(r.body.newPassword,12);write(db);s.json({ok:true})});
app.use((e,r,s,n)=>s.status(400).json({error:e.message||'Request failed'}));
app.listen(PORT,()=>console.log('ZXTRA STORE running on '+PORT));
